请执行
```bash
pip install alibabacloud_dysmsapi20170525==3.1.0
```
来下载依赖包

使用方法见 test.py